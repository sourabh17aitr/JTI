var ihubdata = {
    "username" : "Administrator", 
    "password" : "IHUB$3rv3r",
    "dashboard_name" : "/Applications/JTI Reporting Platform/Dashboards/JTI.dashboard"
}
